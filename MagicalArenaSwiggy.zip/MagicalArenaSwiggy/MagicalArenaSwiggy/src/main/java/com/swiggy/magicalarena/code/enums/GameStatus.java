package main.java.com.swiggy.magicalarena.code.enums;

public enum GameStatus {
    IN_PROGRESS,
    FINISHED
}

