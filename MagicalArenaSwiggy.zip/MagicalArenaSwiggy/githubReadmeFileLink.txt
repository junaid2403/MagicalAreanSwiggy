GitHub repository link for instructions on how to run the magicalArena on your local machine.

https://github.com/junaid2403/MagicalAreanSwiggy